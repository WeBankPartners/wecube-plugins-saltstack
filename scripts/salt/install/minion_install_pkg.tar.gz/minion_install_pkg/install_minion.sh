#!/bin/bash

compare() {
  [ "$1" = "$2" ] && return 1 || [ "$1" = "`echo -e "$1\n$2" | sort -V | head -n1`" ]
}

check_package() {
  package_version=`rpm -qi $1|grep Version|awk -F ":" '{print $2}'|xargs`
  if [ -n "$package_version" ]
  then
    if [ -n $2 ]
    then
      compare $package_version $2 && return 1 || return 0
    else
      return 0
    fi
  else
    return 1
  fi
}

install_package() {
    if [ $1 -eq 0 ]
    then
      echo "$2 already installed"
      return 0
    fi
    index=1
    if [ $# -gt 2 ]
    then
      for arg in $@
      do
        if [ $index -ge 3 ]
        then
          echo "try to install $arg"
          rpm -Uvh `ls | grep $arg | head -n1`
        fi
        let index+=1
        done
    fi
    echo "try to install $2"
    rpm -Uvh `ls | grep $2 | head -n1`
}

#check if exists salt-minion >= 3000.3
minion_version=`rpm -qi "salt-minion"|grep Version|awk -F ":" '{print $2}'|xargs`
if [ -n "$minion_version" ]
then
  compare $minion_version "3000.3"
  if [ $? -eq 1 ]
  then	
    echo "salt-minion already installed >= 3000.3"
    exit 0
  fi
  echo "try to uninstall the old salt-minion version"
  rpm -evh "salt-minion"
fi

#python-setuptools >= 9.1
check_package "python-setuptools" "9.1"
install_package $? "python-setuptools"

#python-jinja2
check_package "python-jinja2"
install_package $? "python-jinja2" "python-babel" "python-markupsafe"

#python-backports-ssl_match_hostname
check_package "python-backports-ssl_match_hostname"
install_package $? "python-backports-ssl_match_hostname" "python-ipaddress" "python-backports"

#python-requests >= 1.0.0
check_package "python-requests" "1.0.0"
install_package $? "python-requests" "python-six" "python-urllib3"

#python2-msgpack >= 0.6
check_package "python2-msgpack" "0.6"
install_package $? "python2-msgpack"

#python-crypto >= 2.6.1
check_package "python2-crypto" "2.6.1"
install_package $? "python-crypto"

#python-zmq
check_package "python-zmq"
install_package $? "python-zmq" "openpgm" "libsodium" "zeromq"

#python-backports_abc
check_package "python-backports_abc"
install_package $? "python-backports_abc" "python-singledispatch" "python-psutil"

#PyYAML
check_package "PyYAML"
install_package $? "PyYAML" "libyaml"

#salt >= 3000.3
check_package "salt" "3000.3"
install_package $? "salt"
rpm -Uvh `ls | grep "salt-minion" | head -n1`
echo "install salt-minion success"
