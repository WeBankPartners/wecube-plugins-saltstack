#!/bin/bash

compare() {
  [ "$1" = "$2" ] && return 1 || [ "$1" = "`echo -e "$1\n$2" | sort -V | head -n1`" ]
}

check_package() {
  package_version=`rpm -qi $1|grep Version|awk -F ":" '{print $2}'|xargs`
  if [ "$1" = "rpm" ]
    then
      package_version=`rpm -qi $1|grep Source|awk -F ":" '{print $2}'|awk -F ".e" '{print $1}'|xargs`
  fi
  if [ -n "$package_version" ]
  then
    if [ -n $2 ]
    then
      compare $package_version $2 && return 1 || return 0
    else
      return 0
    fi
  else
    return 1
  fi
}

install_package() {
    if [ $1 -eq 0 ]
    then
      echo "$2 already installed"
      return 0
    fi
    index=1
    if [ $# -gt 2 ]
    then
      for arg in $@
      do
        if [ $index -ge 3 ]
        then
          if [ "$arg" = "python-urllib3" ]
          then
            mv /usr/lib/python2.7/site-packages/urllib3/packages/ssl_match_hostnam* /tmp/minion_install_pkg/
          fi
          echo "try to install $arg"
          rpm -Uvh `ls | grep $arg | head -n1`
        fi
        let index+=1
        done
    fi
    echo "try to install $2"
    if [ "$2" = "salt" ]
      then
        rpm -Uvh `ls | grep python36-contextvars | head -n1` `ls | grep python36-distro | head -n1` `ls | grep python36-pycurl | head -n1` `ls | grep python36-rpm | head -n1`
	rpm -Uvh `ls | grep salt | head -n1`
      elif [ "$2" = "python3-3.6" ]
      then
	rpm -Uvh `ls | grep libtirpc | head -n1`
	rpm -Uvh `ls | grep python3-3.6 | head -n1` `ls | grep python3-libs | head -n1` `ls | grep python3-pip | head -n1` `ls | grep python3-setuptools | head -n1`
      elif [ "$2" = "rpm-4.11.3-45" ]
      then
	rpm -Uvh `ls | grep rpm-4.11.3-45 | head -n1` `ls | grep rpm-build-libs-4.11.3-45 | head -n1` `ls | grep rpm-libs-4.11.3-45 | head -n1` `ls | grep rpm-python-4.11.3-45 | head -n1`
      else
        rpm -Uvh `ls | grep $2 | head -n1`
    fi
}

#check if exists salt-minion >= 3004.2
minion_version=`rpm -qi "salt-minion"|grep Version|awk -F ":" '{print $2}'|xargs`
if [ -n "$minion_version" ]
then
  compare $minion_version "3004.2"
  if [ $? -eq 1 ]
  then	
    echo "salt-minion already installed >= 3004.2"
    exit 0
  fi
  echo "try to uninstall the old salt-minion version"
  rpm -evh "salt-minion"
fi

#rpm >= 4.11.3.45
check_package "rpm" "rpm-4.11.3-45"
install_package $? "rpm-4.11.3-45"

#python3 >= 3.6
check_package "python3" "3.6"
install_package $? "python3-3.6"

#python-setuptools >= 9.1
#check_package "python3-setuptools" "39.2.0"
#install_package $? "python3-setuptools"

#python-jinja2
check_package "python36-jinja2"
install_package $? "python36-jinja2" "python36-markupsafe"

#python-backports-ssl_match_hostname
#check_package "python-backports-ssl_match_hostname"
#install_package $? "python-backports-ssl_match_hostname" "python-ipaddress" "python-backports"

#python-requests >= 1.0.0
check_package "python36-requests" "2.14.2"
install_package $? "python36-requests" "python36-six" "python36-pysocks" "python36-urllib3" "python36-chardet" "python36-idna"

#python2-msgpack >= 0.6
check_package "python36-msgpack" "0.6.2"
install_package $? "python36-msgpack"

#python-crypto >= 2.6.1
check_package "python36-m2crypto" "0.35.2"
install_package $? "python36-m2crypto"

#python-zmq
check_package "python36-zmq"
install_package $? "python36-zmq" "openpgm" "libsodium" "zeromq"

#python-backports_abc
#check_package "python-backports_abc"
#install_package $? "python-backports_abc" "python-singledispatch" "python-psutil"

#PyYAML
check_package "python36-PyYAML"
install_package $? "python36-PyYAML" "libyaml"

#python-futures
#check_package "python-futures" "2.0"
#install_package $? "python-futures"

#libxml2-python
#check_package "libxml2-python"
#install_package $? "libxml2-python" "libxml2"

#yum-utils
check_package "python36-psutil"
install_package $? "python36-psutil" "hwdata" "pciutils-libs" "pciutils"


#salt >= 3004.2
check_package "salt" "3004.2"
install_package $? "salt" "python36-immutables" "which"
rpm -Uvh `ls | grep "salt-minion" | head -n1`
if [ -f "/usr/bin/salt-minion" ]
then
  echo "salt-minion install success"
else
  echo "salt-minion install fail"
fi
